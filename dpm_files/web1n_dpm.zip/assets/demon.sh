# Script to start "web1n's demon" on the device, which has a very rudimentary
# shell.
#
base=/system

path=`pm path web1n.stopapp`
path=${path:8}

export CLASSPATH=$path
exec app_process $base/bin com.web1n.stopapp.app_process.DemonStart "$@"
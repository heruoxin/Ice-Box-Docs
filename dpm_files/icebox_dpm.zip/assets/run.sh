#!/sbin/busybox sh


##check and install apk
#has_installed_main=`ls /data/app/ | grep icebox | grep -v iceboxsys`
#if [ -z "$has_installed_main" ]; then
#    cp /tmp/com.catchingnow.icebox.apk /data/app/com.catchingnow.icebox.apk 2> /dev/null
#fi

#check and mv plugin
has_priv_folder=`ls /system/ | grep priv-app`
if [ -n "$has_priv_folder" ]; then
    mv /system/app/com.catchingnow.iceboxsystemplugin.apk /system/priv-app/com.catchingnow.iceboxsystemplugin.apk 2> /dev/null
fi

#
chmod -R 777 /data/.icebox

rm -rf /tmp/* 2> /dev/null
